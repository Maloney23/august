# Phantom Interiors - Part 3 updates

Changelog:
- Implemented JS features, SEO, forms validation.


## Changelog (Part 2 feedback — implemented)
- 2025-11-19: Fixed inconsistent stylesheet paths across pages (changed `css/style.css` references to `style.css` in root).
- 2025-11-19: Added `main.js` with robust features: accordions, lightbox gallery, modal dialogs, dynamic product rendering, search/filter, and JSON-LD structured data for SEO.
- 2025-11-19: Replaced/ensured enquiry and contact forms include `id` and `name` attributes for all inputs; implemented client-side validation and error display. Enquiry form provides simulated availability and estimated pricing; contact form compiles a `mailto:` link.
- 2025-11-19: Inserted Leaflet CDN includes and a `#map` element in `contact.html` to display an interactive map showing the main showroom location (requires internet connection to load tiles).
- 2025-11-19: Ensured pages include `<meta charset>` and `<meta name="viewport">` tags for compatibility and mobile-friendliness.
- 2025-11-19: Added `robots.txt` and a basic `sitemap.xml` to assist crawlers.
- 2025-11-19: Implemented accessibility improvements: alt text fallback for images, aria-live on dynamic areas, and semantic headings.
- 2025-11-19: Did not modify or remove any submission-related text or instructions (left as-is per request).

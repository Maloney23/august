/* main.js - Phantom Interiors Part 3 enhancements */
document.addEventListener('DOMContentLoaded', function() {
  // Smooth scroll for same-page anchors
  document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click', function(e){
    const target = document.querySelector(this.getAttribute('href'));
    if(target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth'}); }
  }));

  // Accordion behaviour
  document.querySelectorAll('.accordion-header').forEach(header=>{
    header.addEventListener('click', ()=>{
      const item = header.parentElement;
      const body = item.querySelector('.accordion-body');
      if(!body) return;
      if(item.classList.contains('open')){
        body.style.height = 0;
        item.classList.remove('open');
      } else {
        // close others
        document.querySelectorAll('.accordion-item.open').forEach(openItem=>{
          const b = openItem.querySelector('.accordion-body');
          if(b){ b.style.height = 0; openItem.classList.remove('open'); }
        });
        body.style.height = body.scrollHeight + 'px';
        item.classList.add('open');
      }
    });
  });

  // Create lightbox element
  (function(){
    const lb = document.createElement('div');
    lb.className = 'lightbox-backdrop';
    lb.style.display = 'none';
    lb.innerHTML = '<img alt="Expanded image">';
    document.body.appendChild(lb);
    function openLightbox(src, alt){
      const img = lb.querySelector('img');
      img.src = src; img.alt = alt || 'Image';
      lb.style.display = 'flex';
      lb.setAttribute('aria-hidden','false');
    }
    document.body.addEventListener('click', function(e){
      const t = e.target;
      if(t.matches('img') && (t.classList.contains('gallery-thumb') || t.closest('.products-grid') || t.classList.contains('product-img'))){
        openLightbox(t.dataset.large || t.src, t.alt);
      }
      if(e.target === lb) { lb.style.display = 'none'; lb.setAttribute('aria-hidden','true'); }
    });
  })();

  // Dynamic products rendering if needed
  const productsGrid = document.getElementById('productsGrid') || document.querySelector('.products-grid');
  if(productsGrid && productsGrid.children.length === 0){
    const data = [
      {id:1,name:'Luxury Sofa',price:12990,cat:'seating',img:'products1.jpg',alt:'Luxury Sofa handcrafted'},
      {id:2,name:'Dining Table',price:8990,cat:'tables',img:'products2.jpg',alt:'Solid wood dining table'},
      {id:3,name:'Accent Chair',price:2990,cat:'seating',img:'products3.jpg',alt:'Comfortable accent chair'}
    ];
    data.forEach(p=>{
      const card = document.createElement('div'); card.className = 'product';
      card.innerHTML = `<img class="product-img" src="${p.img}" alt="${p.alt}" data-large="${p.img}"><h3>${p.name}</h3><p>R ${p.price.toLocaleString()}</p><button class="btn" data-modal-target="modal-${p.id}">Details</button>`;
      productsGrid.appendChild(card);
      // modal
      const modal = document.createElement('div'); modal.className='modal'; modal.id='modal-'+p.id;
      modal.innerHTML = `<span class="close">&times;</span><h3>${p.name}</h3><p>Price: R ${p.price.toLocaleString()}</p><p>Category: ${p.cat}</p><p>High quality craftsmanship.</p>`;
      document.body.appendChild(modal);
    });
  }

  // Modal open/close
  document.addEventListener('click', function(e){
    if(e.target.matches('[data-modal-target]')){
      const id = e.target.dataset.modalTarget; const modal = document.getElementById(id); if(modal) modal.classList.add('open');
    } else if(e.target.matches('.modal .close')){
      e.target.closest('.modal').classList.remove('open');
    }
  });

  // Product search
  const search = document.getElementById('productSearch');
  if(search){
    search.addEventListener('input', function(){
      const q = this.value.toLowerCase();
      (document.querySelectorAll('#productsGrid .product')||[]).forEach(card=>{
        const name = (card.querySelector('h3') && card.querySelector('h3').textContent.toLowerCase()) || '';
        card.style.display = name.includes(q)?'':'none';
      });
    });
  }

  // Enquiry form validation + simulated processing
  const enquiryForm = document.getElementById('enquiryForm');
  if(enquiryForm){
    enquiryForm.addEventListener('submit', function(e){
      e.preventDefault();
      const name = this.querySelector('[name="name"]'), email = this.querySelector('[name="email"]'),
            interest = this.querySelector('[name="interest"]'), product = this.querySelector('[name="product"]'),
            message = this.querySelector('[name="message"]');
      const resp = document.getElementById('formResponse');
      const errors = [];
      if(!name || !name.value.trim()) errors.push('Name is required.');
      if(!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)) errors.push('Valid email required.');
      if(!interest || !interest.value) errors.push('Please select the enquiry type.');
      if(!message || message.value.trim().length < 10) errors.push('Message must be at least 10 characters.');
      if(errors.length){ if(resp) resp.innerHTML = '<div class="form-error">'+errors.join('<br>')+'</div>'; return; }
      if(resp) resp.textContent = 'Processing enquiry...';
      setTimeout(()=>{
        const avail = Math.random()>0.35; const est = Math.floor(Math.random()*8000)+199;
        if(resp) resp.innerHTML = `<strong>Thanks ${name.value}.</strong> ${interest.value} ${product && product.value ? 'for \"'+product.value+'\"' : ''} is <strong>${avail?'available':'unavailable'}</strong>. Estimated starting price: R ${est.toLocaleString()}. We will contact you at ${email.value}.`;
      },900);
    });
  }

  // Contact form: validate + mailto compilation
  const contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const cname = this.querySelector('[name="cname"]'), cemail = this.querySelector('[name="cemail"]'),
            ctype = this.querySelector('[name="ctype"]'), cmessage = this.querySelector('[name="cmessage"]');
      const status = document.getElementById('contactStatus');
      const errs = [];
      if(!cname || !cname.value.trim()) errs.push('Name required.');
      if(!cemail || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(cemail.value)) errs.push('Valid email required.');
      if(!cmessage || cmessage.value.trim().length < 10) errs.push('Message must be at least 10 characters.');
      if(errs.length){ if(status) status.innerHTML = '<div class="form-error">'+errs.join('<br>')+'</div>'; return; }
      const recipient = 'info@phantominteriors.example';
      const subject = encodeURIComponent('Website Contact: ' + (ctype && ctype.value ? ctype.value : 'General'));
      const body = encodeURIComponent(`Name: ${cname.value}\nEmail: ${cemail.value}\nType: ${ctype.value}\n\nMessage:\n${cmessage.value}`);
      window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
    });
  }

  // Add alt text fallback for images
  document.querySelectorAll('img').forEach(img=>{ if(!img.getAttribute('alt')) img.setAttribute('alt','Phantom Interiors image'); });

  // Inject JSON-LD structured data for SEO
  const ld = {
    "@context":"https://schema.org",
    "@type":"FurnitureStore",
    "name":"Phantom Interiors",
    "url":location.origin + location.pathname,
    "address":{ "@type":"PostalAddress", "streetAddress":"78 7th Avenue Kensington", "addressLocality":"Kensington", "addressRegion":"Western Cape", "addressCountry":"ZA" }
  };
  const s = document.createElement('script'); s.type='application/ld+json'; s.textContent = JSON.stringify(ld); document.head.appendChild(s);

  // Initialize Leaflet map if #map exists and L is available
  if(typeof L !== 'undefined' && document.getElementById('map')){
    try{
      const map = L.map('map').setView([-33.9258,18.4232], 10);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution:'© OpenStreetMap'}).addTo(map);
      L.marker([-33.9258,18.4232]).addTo(map).bindPopup('Phantom Interiors - Main Showroom').openPopup();
    }catch(e){ console.warn('Leaflet init failed', e); }
  }
});


/* PHANTOM_PART3_SAFE_PATCH */
// Defensive checks added by update script
try{
  if(typeof window !== 'undefined'){
    // ensure DOMContentLoaded handler exists (no-op if already present)
    if(!window.__phantom_part3_dom_ready_registered){
      window.__phantom_part3_dom_ready_registered = true;
      document.addEventListener('DOMContentLoaded', function(){
        // no-op: main functionality is expected to be defined earlier in the file
      });
    }
  }
}catch(e){console.warn('PHANTOM_PATCH_ERROR',e)}
